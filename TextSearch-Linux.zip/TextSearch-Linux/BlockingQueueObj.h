///////////////////////////////////////////////////////////////////////
//  BlockingQueueObj.h - BlockingQueueObject                         //
//  Language:     C++, COM/IDL                                       //
//  Platform:     MSI , Ubuntu                                       //
//  Application:  Distributed Objects (CSE 775)		             //
//  Source:       James Fawcett                                      //
//  Author    : Vishnu Prasad Vishwanathan                           //
//  Referenece:  Jim Fawcett                                         //
//  SUID:        793782749                                           //
//              (315)382-9922,                                       //
//              vvishwan@syr.edu                                     //
// Jim Fawcett, CSE775 - DistributedObjects, Spring 2018             // 
///////////////////////////////////////////////////////////////////////
#pragma once
#include <condition_variable>
#include <mutex>
#include <thread>
#include <queue>
#include <string>
#include <iostream>
#include <sstream>
#include "Cpp11-BlockingQueue.h"

class BlockingQueueObj {
public:
	BlockingQueueObj() {}
	std::string getobj();
	BlockingQueue<std::string> putobj();
	void getqueue(BlockingQueue<std::string> q);
private:
	BlockingQueue<std::string> bq;
};


std::string BlockingQueueObj::getobj()
{
	std::string returnstr = bq.deQ();
	return returnstr;
}

void BlockingQueueObj::getqueue(BlockingQueue<std::string> q)
{
	bq = q;
}
BlockingQueue<std::string> BlockingQueueObj::putobj()
{
	return bq;
}

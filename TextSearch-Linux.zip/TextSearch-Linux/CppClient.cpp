////////////////////////////////////////////////////////////////////////////////
//  CppClient.cpp - Demonstrate Component                                     //
//  Language:     C++, COM/IDL                                                //
//  Platform:     MSI , Ubuntu                                                //
//  Application:  Distributed Objects (CSE 775)				      //
//  Source:       James Fawcett                                               //
//  Author    : Vishnu Prasad Vishwanathan                           //
//  Referenece:  Jim Fawcett                                         //
//  SUID:        793782749                                           //
//              (315)382-9922,                                       //
//              vvishwan@syr.edu                                     //
// Jim Fawcett, CSE775 - DistributedObjects, Spring 2018             // 
///////////////////////////////////////////////////////////////////////

#include "ITest.h"
#include "ISearch.h"
#include  <iostream>
#include <vector>
#include <dlfcn.h>  // get access to dlopen and dlsym
int main(int argv, char* args[])
{
  std::cout << "\n  Text Search Component Linux Version" << "\n =======================================\n";
  std::string pathstr, regexstr;
  std::vector<std::string> patterns;
  if (argv < 3){
	std::cout << "\n Taking Default arguments";	  
	pathstr = "../";
	regexstr = "inc";
 	patterns.push_back("h");
  	patterns.push_back("cpp");
  }
  else {
	regexstr = std::string(args[1]);
	  pathstr = std::string(args[2]);
	  std::cout << "\nPath: " << pathstr << "\nRegex string: " << regexstr << "\nPattterns: ";	 
	  for (int i = 3; i<int(argv); i++){
		  patterns.push_back(std::string(args[i]));
		  std::cout << "\n" << args[i];
	  }
  }
 void* handle = dlopen("./FileComponent.so", RTLD_LAZY);
  if (!handle){
    std::cout << "\n  failed to load FileComponent.so\n\n";
    return 1; }
  typedef ITest*(*GCreate)();
  GCreate gCreate = (GCreate)dlsym(handle, "globalCreateTest");
  if (!gCreate){
    std::cout << "\n  failed to acquire create function\n\n";
    return 1; } 
  ITest* pFileMgr = gCreate();
  pFileMgr->getelements(pathstr,patterns);
  void* searchhandle = dlopen("./searchComponent.so", RTLD_LAZY);
  if (!searchhandle){
    std::cout << "\n  failed to text searchComponent.so\n\n";
    return 1; }
  typedef ISearch*(*SCreate)();
  SCreate searchCreate = (SCreate)dlsym(searchhandle, "globalCreateSearch");
  if (!searchCreate){
    std::cout << "\n  failed to acquire create function\n\n";
    return 1; }
  ISearch* pSearchMgr = searchCreate();
  pSearchMgr->getFilePtr(pFileMgr);
  std::vector<std::string> filenames = pSearchMgr->getFileResults(regexstr);
  std::cout << "\n =======================================\n"<< "\n  	Final Output"  << "\n =======================================\n";
  for(int i=0; i < int(filenames.size()); i++){
    std::cout << "\n"<< filenames[i];  }
  std::cout << "\n\n";
  dlclose(searchhandle);
  dlclose(handle);
}

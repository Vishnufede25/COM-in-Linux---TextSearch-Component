////////////////////////////////////////////////////////////////////////////////
// Component.cpp - Demonstrate Component                                      //
//  Language:     C++, COM/IDL                                                //
//  Platform:     MSI , Ubuntu                                                //
//  Application:  Distributed Objects (CSE 775)                               //
//  Source:       James Fawcett                                               //
//  Author    : Vishnu Prasad Vishwanathan                           //
//  Referenece:  Jim Fawcett                                         //
//  SUID:        793782749                                           //
//              (315)382-9922,                                       //
//              vvishwan@syr.edu                                     //
// Jim Fawcett, CSE775 - DistributedObjects, Spring 2018             // 
///////////////////////////////////////////////////////////////////////

/*-------  Functions --------------------------------------------------------------------
 1 processResults- gets the files residing in the given path
   2 getelements-    gets the path and patterns
   3 getFilePath-    dequeue the Blockingqueue
*/

#include "ITest.h"
#include <iostream>
#include "FileSystem.h"
#include <vector>


using namespace FileSystem;
class TestDriver : public ITest
{
 public:
   TestDriver(void);
   virtual ~TestDriver(void);
   void getelements(std::string path, std::vector<std::string> patterns);
   void getFilePtr(ITest* pFileMgr);
   //void getResults(std::vector<std::string> &results);
   //std::vector<std::string> getResults();  
   bool processResults();
   std::string getFilePath();
   private:
      // BlockingQueueObj obj;
       std::string path_;
       std::vector<std::string> patterns_;
};

//----< TestDriver Created >--------
TestDriver::TestDriver(void)
{
  std::cout << "\n  FileSearch created\n";
}

//----< TestDriver Destroyed >--------
TestDriver::~TestDriver(void)
{
  std::cout << "\n  FileSearch destroyed\n";
}

//----< createTest >--------
ITest* ITest::createTest()
{
  return new TestDriver;
}

//----< globalCreateTest >--------
ITest* globalCreateTest()
{
  return new TestDriver;
}

//----< get path and patterns >--------
void TestDriver::getelements(std::string path, std::vector<std::string> patterns)
{
    path_ = path;
    for(int i=0;i < (int)patterns.size();i++)
    {
        patterns_.push_back(patterns[i]);
    }
}


//----< adding to Blocking Queue >--------
bool TestDriver::processResults()
{
	BlockingQueue<std::string> bbq;
	std::vector<std::string> files;
  	Directory::getAll(files,path_,patterns_);
	for(int i=0;i < (int)files.size();i++)
    	{
        	bbq.enQ(files[i]);
    	}
	bbq.enQ("quit");
	obj.getqueue(bbq);
	std::cout << "\nReceived all the filenames and added them to the BlockingQueue\n";
	return true;
}

//----< Processing the Blocking Queue >--------
std::string TestDriver::getFilePath()
{
	std::cout <<"\n Accessing the BlockingQueue - deQ() operation for a file\n"; 
	BlockingQueue<std::string> bbq = obj.putobj();
	if (bbq.size() > 0)
	{
		std::string dequeuestr = bbq.deQ();
		obj.getqueue(bbq);
		return	dequeuestr;
	}
	else
	{
		return "quit";
	}	
}

//----< test stub >--------------------------------------------------------


#ifdef TEST_COMPONENT
int main()
{
	std::cout << "testing: \n";
	std::vector<std::string> filess;
	std::vector<std::string> patterns;
        patterns.push_back("h");
        TestDriver td ;
	td.processResults();
	std::string str = td.getFilePath();
	return 0;
}
#endif

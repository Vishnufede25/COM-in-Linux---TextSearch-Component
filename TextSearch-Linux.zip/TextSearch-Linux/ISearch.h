#pragma once
////////////////////////////////////////////////////////////////////////////////
// ISearch.h -      Search Component Interface                                //
//  Language:     C++, COM/IDL                                                //
//  Platform:     MSI , Ubuntu                                                //
//  Application:  Distributed Objects (CSE 775)                               //
//  Source:       James Fawcett                                               //
//  Author    : Vishnu Prasad Vishwanathan                           //
//  Referenece:  Jim Fawcett                                         //
//  SUID:        793782749                                           //
//              (315)382-9922,                                       //
//              vvishwan@syr.edu                                     //
// Jim Fawcett, CSE775 - DistributedObjects, Spring 2018             // 
///////////////////////////////////////////////////////////////////////
//Interface for SearchCOmponent

#include <iostream>
#include<vector>
#include "ITest.h"

class ISearch
{
 public:
  virtual ~ISearch(void) {}
  static ISearch* createSearch();  // built-in factory
  virtual  void getFilePtr(ITest* pFileMgr) = 0;
  virtual std::vector<std::string> getFileResults(std::string regexline) = 0;
};

extern "C" {                  // unmangled global factory
  ISearch* globalCreateSearch();
}

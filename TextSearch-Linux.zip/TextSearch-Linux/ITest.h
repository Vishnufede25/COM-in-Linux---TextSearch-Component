#pragma once
////////////////////////////////////////////////////////////////////////////////
//  ITest.h -      FileManager Interface Component                            //
//  Language:     C++, COM/IDL                                                //
//  Platform:     MSI , Ubuntu                                                //
//  Application:  Distributed Objects (CSE 775)                               //
//  Source:       James Fawcett                                               //
//  Author    : Vishnu Prasad Vishwanathan                           //
//  Referenece:  Jim Fawcett                                         //
//  SUID:        793782749                                           //
//              (315)382-9922,                                       //
//              vvishwan@syr.edu                                     //
// Jim Fawcett, CSE775 - DistributedObjects, Spring 2018             // 
///////////////////////////////////////////////////////////////////////

#include <iostream>
#include<vector>
#include "BlockingQueueObj.h"
class ITest
{
 public:
  virtual ~ITest(void) {}
  static ITest* createTest();  // built-in factory
  virtual void getelements(std::string path, std::vector<std::string> patterns) = 0;
  virtual  bool processResults() = 0;
  virtual  std::string getFilePath() = 0;
 // private:
	//Directory d;	
       //std::string path_;
       //std::vector<std::string> patterns_;
       BlockingQueueObj obj;
};


extern "C" {                  // unmangled global factory
  ITest* globalCreateTest();
}

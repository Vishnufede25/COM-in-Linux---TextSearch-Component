////////////////////////////////////////////////////////////////////////////////
//  TextSearchComp.cpp - TextSearch Component                                //
//  Language:     C++, COM/IDL                                                //
//  Platform:     MSI , Ubuntu                                                //
//  Application:  Distributed Objects (CSE 775)                               //
//  Source:       James Fawcett                                               //
//  Author    : Vishnu Prasad Vishwanathan                           //
//  Referenece:  Jim Fawcett                                         //
//  SUID:        793782749                                           //
//              (315)382-9922,                                       //
//              vvishwan@syr.edu                                     //
// Jim Fawcett, CSE775 - DistributedObjects, Spring 2018             // 
///////////////////////////////////////////////////////////////////////

/*-------  Functions --------------------------------------------------------------------

1 getFilePtr-        get the IfilePtr   
2 getfile-           get each file from BLockingqueue
3 getFileResults-    get all the results from textsearch
4 putregex, getregex put and get for regexstring
*/

#include "ISearch.h"
#include "ITest.h"
#include <iostream>
#include "FileSystem.h"
#include <vector>
#include <regex>
#include <mutex>
#include <pthread.h>
#include <queue>

std::mutex ioLock1;
pthread_mutex_t mutex;  
class TextSearch : public ISearch
{
  public:
	   TextSearch(void);
	   virtual ~TextSearch(void);
	   void getFilePtr(ITest* pFileMgr);
	   std::string getfile(std::string &resultf);
	   std::vector<std::string> getFileResults(std::string regexline);
	   void putregex(std::string reg);
	   std::string getregex();
   private:
	std::string regexl;
	ITest* ptr;
        std::vector<std::string> Filess;
};

//----< get pointer to FileMgr>--------
void TextSearch::getFilePtr(ITest* FileMgr)
{
    ptr = FileMgr;
}

//----< TextSearch Created >--------
TextSearch::TextSearch(void)
{
  std::cout << "\n  TextSearch created\n";
}

//----< TextSearch Destroyed >--------
TextSearch::~TextSearch(void)
{
  std::cout << "\n  TextSearch destroyed\n";
}

//----< createSearch >--------
ISearch* ISearch::createSearch()
{
  return new TextSearch;
}

//----< globalCreateSearch >--------
ISearch* globalCreateSearch()
{
  return new TextSearch;
}


//----< Put Regex >--------
void TextSearch::putregex(std::string reg)
{
	this->regexl = reg;
}

//----< Get Regex >--------
std::string TextSearch::getregex()
{
	return regexl;
}


//----< Text Search Results >--------
std::string TextSearch::getfile(/*std::string regexline,*/ std::string &resultf)
{
  ITest* fileptr = ptr;
  std::string resfile = fileptr->getFilePath();
  std::regex pattern(regexl);	 
  std::string line;
  std::ifstream infile;
  std::cout << "trying to open : " << resfile<<"\n";
    infile.open(resfile);
    int linenum = 0;
    
    if(infile.is_open())
    {
	resfile += "\nLine numbers: "; 
      
      while(getline(infile,line))
      {
	linenum++;
        if(std::regex_search(line,pattern))
        {
	  resfile += "\n";
	  resfile += std::to_string(linenum);
	  resfile += "\n";
        }
      }
	resfile += "\n";
    }
    
    else
    {
       std::cout << "\nError opening file: " << resfile<< "\n";
    }	
    infile.close();	
    return resfile;
}

//----< Getting Final REsults from Blocking Queue >--------
std::vector<std::string> TextSearch::getFileResults(std::string regexline)
{
  std::vector<std::string> filenames;
  std::string resultf2;
  this->putregex(regexline);
   if(ptr->processResults())
  {
	while(true)
	{
		std::string resultf;
		std::string str1 = getfile(resultf);
		{
			 
		      std::lock_guard<std::mutex> l(ioLock1);
		    		
		}
		if(str1.compare("quit") == 0)
		{
			break;
		}
		filenames.push_back(str1);		
		std::this_thread::sleep_for(std::chrono::milliseconds(3));
		
  	}	
  }

  return filenames;
}
 
//----< test stub >--------------------------------------------------------

#ifdef TEST_TEXTSEARCHCOMP

int main()
{
	std::cout << "testing: \n";
	std::vector<std::string> filess;
	std::vector<std::string> patterns;
        patterns.push_back("h");
	std::string regexsstr = "inc";
        TestSearch td ;
	td.getFilePtr(ITest* pFileMgr);
	std::vector<std::string> res = td.getFileResults(std::string regexline);
	return 0;
}
#endif 

echo "\n\n Running Cppclient with regex:inc path: /test patterns \ h txt cpp"
./CppClient.o "(\\+|-)?[[:digit:]]+" ../TextSearch-Linux/test/ cpp h txt cs 

/////////////////////////////////////////////////////////////
// Component.cpp - Demonstrate Component                   //
//                 - Implements interface                  //
//                 - Defines object factory                //
//                 - built as DLL                          //
//                                                         //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2015  //
/////////////////////////////////////////////////////////////
/*
 *  This component pretends to be a test driver
 */

#include "ITest.h"
#include <iostream>

class TestDriver : public ITest
{
public:
  TestDriver(void);
  virtual ~TestDriver(void);
  virtual bool test();
  // inherits static creational function
};

TestDriver::TestDriver(void)
{
  std::cout << "\n  TestDriver created";
}

TestDriver::~TestDriver(void)
{
  std::cout << "\n  TestDriver destroyed";
}

ITest* ITest::createTest()
{
  return new TestDriver;
}

ITest* globalCreateTest()
{
  return new TestDriver;
}

bool TestDriver::test()
{
  // put calls into tested code here
  // and return pass status not the
  // automatic fail below
  std::cout << "\n  This test always fails.";
  return false;
}

